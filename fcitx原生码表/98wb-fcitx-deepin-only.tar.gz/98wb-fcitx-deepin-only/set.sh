#!/bin/bash
sudo apt purge sogou* fcitx
rm -rf ~/.sogouinput
rm -rf ~/.config/sogou-qimpanel
rm -rf ~/.config/SogouPY*
sudo rm -rf /usr/share/fcitx/inputmethod/sogoupinyin.conf
sudo rm -rf /usr/share/fcitx/table /usr/share/im-config/data/21_ibus*
sudo rm -rf /usr/share/fcitx/data/punc*_*
sudo apt install fcitx fcitx-table fcitx-tools zenity
sudo cp -rf ./fcitx /usr/share
mkdir -p ~/.config/fcitx/skin
cp -rf ./98wb-B ~/.config/fcitx/skin/
sudo chmod -R 777 /usr/share/fcitx
echo "已成功为『fcitx』添加『98五笔』，请重启或注销系统一次后，在对应的设置面板中添加！"
