#!/bin/bash
sudo apt purge sogou* fcitx -y
rm -rf ~/.sogouinput
rm -rf ~/.config/sogou-qimpanel
rm -rf ~/.config/SogouPY*
sudo rm -rf /usr/share/fcitx/inputmethod/sogoupinyin.conf
sudo rm -rf /usr/share/fcitx/table /usr/share/im-config/data/21_ibus*
sudo rm -rf /usr/share/fcitx/data/punc*_*

echo "准备工作已毕，请先注销系统，再正常安装小小输入法！"
